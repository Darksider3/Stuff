"use strict";
var DEBUGVAR = true;
const SVGGrid = {
  init: function (ctx, ele, count = 8, size = 400) {
    this.element = ele;
    this.ctx = ctx;
    this.count = count;
    this.size = size;
    this.activated = false;
    this.gridSVGs = {
      8: {
        img: "8x8.svg"
      },
      16: {
        img: "16x16.svg"
      },
      32: {
        img: "32x32.svg"
      }
    };
    return this;
  },

  adjust: function (count, size) {
    this.count = count;
    this.size = size;
    if (this.activated) {
      this.draw();
    }
  },

  draw: function () {
    this.activated = true;
    this.element.style.background = "url(" + this.gridSVGs[this.count].img + ")";
    this.element.style.backgroundSize = "cover";
  }
};

const Rects = {
  init: function (ctx, count = 8, RectSize = 37.5, PxSize = 300, color = "#29FF81") {
    this.px = PxSize;
    this.ctx = ctx;
    this.count = count;
    this.RectSize = RectSize;
    this.Rects = createArray(this.count, this.count);
    this.drawn = false;
    this.filler = false;
    this.fillStyle = color;
    this.Size = {
      x: this.RectSize * (this.count),
      y: this.RectSize * (this.count)
    };

    this.previous = null;
    this.adjust(this.count, this.RectSize); // draw initial
    return this;
  },

  adjust: function (count, RectSize) {
    this.count = count;
    this.RectSize = RectSize;
    this.Rects = createArray(this.count, this.count);
    if(this.drawn)
    {
      for(let i = 0; i < this.Rects.length; ++i)
      {
        for(let j = 0; j < this.Rects[i].length; ++j)
        {
          this.fillStyle = "rgba(250, 250, 250, 256)";
          this.fillShape(i*this.RectSize, j*this.RectSize);
        }
      }
    }
  },

  flatten: function (x, y) {
    return {
      x: Math.floor(x / this.RectSize) * this.RectSize,
      y: Math.floor(y / this.RectSize) * this.RectSize
    };
  },

  translateToArray: function(x, y)
  {
    return {x: Math.floor(x / this.RectSize), y: Math.floor(y/this.RectSize)};
  },

  isRectSet: function (x, y) {
    let flat = flatten(x, y);
    if (!isset(this.Rects[y][x]) || this.Rects[y][x] == null) {
      return false;
    }
    return true;
  },

  setPrevious: function (x, y) {
    let flat = this.flatten(x, y);
    this.previous = flat;
  },

  isSameRect: function (x, y) {
    let flat = this.flatten(x, y);
    if (flat.x == this.previous.x && flat.y == this.previous.y)
      return true;
    else
      return false;
  },

  clear: function () {
    this.ctx.clearRect(0, 0, canvas.width, canvas.height);
    this.Rects = createArray(this.count, this.count);
  },

  inBetween: function(oldcolor, newcolor, bound) {

    let oldColInt = Math.floor(parseInt(oldcolor.substring(1), 16) / 10000);
    let NewColInt = Math.floor(parseInt(newcolor.substring(1), 16) / 10000);
    return between(NewColInt, oldColInt-bound, oldColInt+bound);

  },

  fillShape: function (x, y) {
    //floor it first so we get always the correct rectangle to work with
    let xArr = Math.floor(x / this.RectSize),
      yArr = Math.floor(y / this.RectSize);

    x = xArr * this.RectSize;
    y = yArr * this.RectSize;
    if (x > this.px - 1)
      return;
    if (y > this.px - 1)
      return;
    if(this.filler)
    {
      let oldcolor = imgdataToRGB(this.ctx.getImageData(x+(this.RectSize/2), y+(this.RectSize/2), 1, 1).data).toUpperCase();
      this.fill(x, y, oldcolor, "#912BCA");
      return; 
    }
    this.Rects[yArr][xArr] = new String(this.fillStyle);
    this.Rects[yArr][xArr] = this.fillStyle;
    this.ctx.fillStyle = this.fillStyle;
    this.ctx.fillRect(x, y, this.RectSize + 1, this.RectSize + 1);
  },

  fill: function(xcord, ycord, old, newColor) {
    let touched = createArray(this.count+1, this.count+1);
    let Stack = [];
    Stack.push({
      x: xcord,
      y: ycord
    });
    this.fillStyle = newColor;
    this.filler = false;
    while (Stack.length != 0) {
      var coords = Stack.pop();
      var Arr = this.translateToArray(coords.x, coords.y);
      if(coords.x < 0 || coords.y < 0  || Arr.x > this.count || Arr.y > this.count)
      {
        continue;
      }
      if(touched[Arr.y][Arr.x] == true)
        continue;
      
      let flatCoords = this.flatten(coords.x, coords.y);
      let pixelCol = imgdataToRGB(this.ctx.getImageData(flatCoords.x+(this.RectSize/2), flatCoords.y+(this.RectSize/2), 1, 1).data).toUpperCase();
      touched[Arr.y][Arr.x] = true;
      if (pixelCol == old || this.inBetween(old, pixelCol, 5)) {
        // bounds check(we dont have to iterate over non-existent cols&rows)
        if ((Arr.x+1)*this.RectSize > this.px +2)
        {
          continue;
        }
        if ((Arr.y+1)*this.RectSize > this.px +2)
        {
          continue;
        }
        this.fillShape(coords.x, coords.y);
        Stack.push({ x: Arr.x*this.RectSize, y: (Arr.y + 1)*this.RectSize});
        Stack.push({ x: Arr.x*this.RectSize, y: (Arr.y- 1)*this.RectSize});
        Stack.push({ x: ( Arr.x +1)*this.RectSize , y: Arr.y*this.RectSize});
        Stack.push({ x: ( Arr.x -1)*this.RectSize , y: Arr.y*this.RectSize});
      }
    }
    this.filler = true; 
    return;
  }
};

function isset(variable) {
  return typeof variable !== 'undefined'
}

function createArray(length) {
  let arr = new Array(length || 0),
    i = length;

  if (arguments.length > 1) {
    var args = Array.prototype.slice.call(arguments, 1);
    while (i--) arr[length - 1 - i] = createArray.apply(this, args);
  }

  return arr;
}

function imgdataToRGB(imgdata) {
  let returner = "#";
  for(let i = 0; i < imgdata.length-1; ++i)
  {
    returner += imgdata[i].toString(16);
  }
  return returner;
}

function between(x, min, max) {
  return x >= min && x <= max;
}


function DEBUG(message) {
  if(DEBUGVAR == true)
    console.log(message);
  else
    ;
}
