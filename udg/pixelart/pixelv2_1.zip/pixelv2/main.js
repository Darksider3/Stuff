"use strict";
let dragged = false,
  canvasElem = document.querySelector("canvas"),
  canvas = document.getElementById("canvas"),
  context = canvas.getContext("2d"),
  SVG = SVGGrid.init(context, canvasElem),
  Rec = Rects.init(context);

// set devicePixelRatio to a HiDi-specific value(better colors on good screens)
window.devicePixelRatio = 2.5;

// Turn off smoothing
context.imageSmoothingEnabled = false;
context.mozImageSmoothingEnabled = false;
context.oImageSmoothingEnabled = false;
context.webkitImageSmoothingEnabled = false;
context.msImageSmoothingEnabled =false;


// Finally, draw.
SVG.draw();

// HTML specific function

function generic(Rec, SVG, multiplier=2, gridpxsize=400)
{
  Rec.clear();
  Rec.adjust(8*multiplier, 37.5*multiplier);
  SVG.adjust(8*multiplier, gridpxsize);
}

function eight() {
  Rec.clear();
  Rec.adjust(8, 37.5);
  SVG.adjust(8, 400);
}

function sixteen() {
  Rec.clear();
  Rec.adjust(16, 18.75);
  SVG.adjust(16, 400);
}
function thirtyTwo() {
  Rec.clear();
  Rec.adjust(32, 9.4);
  SVG.adjust(32, 400);
}

function fillFunc() {
  Rec.filler = true;
}

function getMousePosition(canvas, event) {
  let rect = canvas.getBoundingClientRect(),
    x = event.clientX - rect.left,
    y = event.clientY - rect.top,
    Coords = { x: 0, y: 0 };
    DEBUG("Coordinate x: " + x, "Coordinate y: " + y);
  return (Coords = {
    x: x,
    y: y
  });
}

function draggedDraw(e) {
  if (dragged) {
    // safety ftw!
    let moveCoords = getMousePosition(canvasElem, e);
    if (Rec.isSameRect(moveCoords.x, moveCoords.y) != true) {
      Rec.fillShape(moveCoords.x, moveCoords.y);
      Rec.setPrevious(moveCoords.x, moveCoords.y);
    }
  }
}

canvasElem.addEventListener("mousedown", function(e) {
  let coords = getMousePosition(canvasElem, e);
  Rec.fillStyle = getRandomColorRGBA()
  Rec.fillShape(coords.x, coords.y);
  dragged = true;
  Rec.setPrevious(coords.x, coords.y);
  canvasElem.addEventListener("mousemove", draggedDraw);
});

canvasElem.addEventListener("mouseup", function(e) {
  dragged = false;
  canvasElem.removeEventListener("mousemove", draggedDraw);
});

function getRandomColor() {
  let letters = "0123456789ABCDEF",
    color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

function getRandomColorRGBA() {
  let color = "rgba(";
  for (let i = 0; i < 3; ++i) {
    color += Math.floor(Math.random() * 256);
    color += ",";
  }
  color += "256)";
  return color;
}
