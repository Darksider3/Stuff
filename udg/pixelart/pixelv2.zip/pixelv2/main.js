/*
 * MIT License
 *
 * Copyright (c) 2020 darksider3 < github@darksider3.de >
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the
 * Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH
 * THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */


"use strict";
let dragged = false,
  canvasElem = document.querySelector("canvas"),
  canvas = document.getElementById("canvas"),
  context = canvas.getContext("2d"),
  toggleButton = document.getElementById('gridtoggle'),
  SVG = SVGGrid.init(context, canvasElem),
  Rec = Rects.init(context);

// set devicePixelRatio to a HiDi-specific value(better colors on good screens)
window.devicePixelRatio = 2.5;

// Turn off smoothing
context.imageSmoothingEnabled = false;
context.mozImageSmoothingEnabled = false;
context.oImageSmoothingEnabled = false;
context.webkitImageSmoothingEnabled = false;
context.msImageSmoothingEnabled = false;

// Finally, draw.
SVG.draw();

// HTML specific function

function GenericGrid(Rec, SVG, multiplier = 2, gridpxsize = 400) {
  Rec.clear();
  Rec.adjust(8 * multiplier, 37.5 * multiplier);
  SVG.adjust(8 * multiplier, gridpxsize);
}

function EightGrid() {
  Rec.clear();
  Rec.adjust(8, 37.5);
  SVG.adjust(8, 400);
}

function SixteenGrid() {
  Rec.clear();
  Rec.adjust(16, 18.75);
  SVG.adjust(16, 400);
}

function fillFunc(element) {
  if(Rec.FloodFill)
  {
    Rec.FloodFill = false;
    element.textContent = "Flood Fill! "
  }
  else {
    Rec.FloodFill = true;
    element.textContent = "Pixel Fill!";
  }
}

function getMousePosition(canvas, event) {
  let rect = canvas.getBoundingClientRect(),
    x = event.clientX - rect.left,
    y = event.clientY - rect.top,
    Coords = { x: 0, y: 0 };
  DEBUG("Coordinate x: " + x, "Coordinate y: " + y);
  return (Coords = {
    x: x,
    y: y
  });
}

function draggedDraw(e) {
  if (dragged) {
    // safety ftw!
    let moveCoords = getMousePosition(canvasElem, e);
    if (Rec.isSameRect(moveCoords.x, moveCoords.y) != true) {
      Rec.fillShape(moveCoords.x, moveCoords.y);
      Rec.setPrevious(moveCoords.x, moveCoords.y);
    }
  }
}

function getRandomColor() {
  let letters = "0123456789ABCDEF",
    color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

function getRandomColorRGBA() {
  let color = "rgba(";
  for (let i = 0; i < 3; ++i) {
    color += Math.floor(Math.random() * 256);
    color += ",";
  }
  color += "256)";
  return color;
}
