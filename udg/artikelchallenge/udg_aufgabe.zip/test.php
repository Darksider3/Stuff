<?php
echo htmlspecialchars("<maskjd></maskjd>",  ENT_QUOTES, 'UTF-8');
